"""
Module containing private utility functions
===========================================

The ``ndimage._lib`` namespace is empty (for now).

"""
